$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $PSScriptRoot
$Python = Join-Path $Root ".venv\Scripts\python.exe"
$AppDir = "E:\科研记录"
$Backup = Join-Path $AppDir ("backup_" + (Get-Date -Format "yyyyMMdd_HHmmss"))

if (!(Test-Path $Python)) {
  throw "Virtual environment not found. Create it and install requirements first."
}

Push-Location $Root
& $Python -m PyInstaller --noconfirm --clean --onefile --windowed `
  --name "科研记录" `
  --paths "src" `
  "launcher.py"

New-Item -ItemType Directory -Force $AppDir | Out-Null
New-Item -ItemType Directory -Force $Backup | Out-Null

foreach ($name in @("config.json", "数据", "assets", "科研记录.exe")) {
  $p = Join-Path $AppDir $name
  if (Test-Path $p) {
    Move-Item -LiteralPath $p -Destination (Join-Path $Backup $name)
  }
}

Copy-Item -LiteralPath (Join-Path $Root "dist\科研记录.exe") -Destination (Join-Path $AppDir "科研记录.exe") -Force
Pop-Location

Write-Host "Built and installed to $AppDir"
Write-Host "Backup: $Backup"
